<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<head>
	<title>Ponto de Venda</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- bootstrap-css -->
	<link rel="stylesheet" href="css/bootstrap.min.css" >
	<!-- //bootstrap-css -->
	<!-- Custom CSS -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link href="css/style-responsive.css" rel="stylesheet"/>
	<!-- font CSS -->
	<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<!-- font-awesome icons -->
	<link rel="stylesheet" href="css/font.css" type="text/css"/>
	<link href="css/font-awesome.css" rel="stylesheet"> 
	<!-- //font-awesome icons -->
	<script src="js/jquery2.0.3.min.js"></script>
</head>
<body>
	<div class="log-w3">
		<div class="w3layouts-main">
			<?php
				if(isset($_GET['login'])){
					if($_GET['login'] == 'erro'){
						echo '<div class="alert alert-danger" role="alert">
								<strong>Erro ao efetuar o login!</strong> Tente Novamente!
							  </div>';		
					}
					if($_GET['login'] == 'semsessao'){
						echo '<div class="alert alert-warning" role="alert">
								<strong>Atenção! Faça login no sistema!</strong>
							  </div>';
					}
				}
				if(isset($_GET['saiu'])){
					if($_GET['saiu'] == 'ok'){
						echo '<div class="alert alert-info" role="alert">
								<strong>Logout efetuado com sucesso!</strong>
							  </div>';
					}
				}
				if(isset($_GET['temgente'])){
					if($_GET['temgente'] == 'ok'){
						echo '<div class="alert alert-info" role="alert">
								<strong>Aguarde sua vez!</strong>
								<br>
								<strong>Tem uma pessoa logada no sistema!</strong>
					  		  </div>';
					}
				}
			?>
			<h2>Login</h2>
				<form method="POST" action="login.php">
					<input type="text" class="ggg" name="nome" placeholder="Digite o seu nome" required="">
					<input type="email" class="ggg" name="email" placeholder="Digite o seu email" required="">
					<input type="text" class="ggg" name="telefone" placeholder="Digite o seu número de telefone" required="">					
					<div class="clearfix"></div>
					<input type="submit" value="Entrar" name="login">
				</form>
				<p>Você ainda não possui um cadastro?</p>
				<p><a href="usuario/cadastro.php" rel="next" target="_self">Cadastre-se Aqui!</a></p>
		</div>
	</div>
	<script>
		$(document).ready(function(){
			$('.alert').delay(3000);
			$('.alert').hide(2000);
		});
	</script>
	<script src="js/bootstrap.js"></script>
	<script src="js/jquery.dcjqaccordion.2.7.js"></script>
	<script src="js/scripts.js"></script>
	<script src="js/jquery.slimscroll.js"></script>
	<script src="js/jquery.nicescroll.js"></script>
	<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
	<script src="js/jquery.scrollTo.js"></script>
</body>
</html>
